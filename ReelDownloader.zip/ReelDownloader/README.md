# ReelDownloader

Android Reel Downloader starter app using a user-configured Cobalt API instance.

## Features
- Paste public Instagram URL
- Fetch media URL through Cobalt
- 1080p / 720p / 480p / 360p selection
- MP3 audio download
- Android DownloadManager progress/notification
- Download history
- WhatsApp share after completion
- Cobalt API URL + optional API key settings

## Important
Use this only for public content you own or have permission to download. Do not bypass private accounts or access controls.

Cobalt's current API uses `POST /` with JSON such as `url`, `downloadMode`, `videoQuality`, and `audioFormat`. Hosted API instances may restrict third-party use, so configure your own permitted instance.

## Build
The project uses Android Gradle Plugin 9.4.0 and Gradle 9.6.0. JDK 17 is required. See the included GitHub Actions workflow for cloud builds.
