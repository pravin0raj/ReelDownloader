package com.pravin0raj.reeldownloader;
import android.app.*; import android.os.*; import android.view.*; import android.widget.*; import android.content.*;
public class SettingsActivity extends Activity{
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,30,24,24); l.setBackgroundColor(0xFF0F0B17);
 TextView t=new TextView(this);t.setText("Cobalt API Settings");t.setTextColor(0xFFFFFFFF);t.setTextSize(24);t.setTypeface(null,1);l.addView(t);
 EditText api=new EditText(this);api.setHint("https://your-cobalt-instance/");api.setSingleLine(true);api.setTextColor(0xFFFFFFFF);api.setHintTextColor(0xFFAAA0B8);api.setText(getSharedPreferences("settings",0).getString("api",""));l.addView(api);
 EditText key=new EditText(this);key.setHint("API key (optional)");key.setSingleLine(true);key.setTextColor(0xFFFFFFFF);key.setHintTextColor(0xFFAAA0B8);key.setText(getSharedPreferences("settings",0).getString("key",""));l.addView(key);
 Button save=new Button(this);save.setText("Save");l.addView(save);save.setOnClickListener(v->{getSharedPreferences("settings",0).edit().putString("api",api.getText().toString().trim()).putString("key",key.getText().toString().trim()).apply();Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();finish();});setContentView(l);}
}
