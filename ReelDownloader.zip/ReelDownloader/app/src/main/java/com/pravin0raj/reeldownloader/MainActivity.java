package com.pravin0raj.reeldownloader;

import android.app.*;
import android.app.DownloadManager;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText urlInput; Button fetchButton, videoBtn, audioBtn, settingsBtn; Spinner quality; VideoView preview; LinearLayout resultCard; TextView resultTitle, historyText;
    String resolvedUrl="", resolvedFilename="reel_download.mp4";
    android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(com.pravin0raj.reeldownloader.R.layout.activity_main);
        prefs=getSharedPreferences("settings",MODE_PRIVATE); bind(); showHistory();
    }
    void bind(){
        urlInput=findViewById(R.id.urlInput); fetchButton=findViewById(R.id.fetchButton); videoBtn=findViewById(R.id.downloadVideoButton); audioBtn=findViewById(R.id.downloadAudioButton); settingsBtn=findViewById(R.id.settingsButton); quality=findViewById(R.id.qualitySpinner); preview=findViewById(R.id.videoPreview); resultCard=findViewById(R.id.resultCard); resultTitle=findViewById(R.id.resultTitle); historyText=findViewById(R.id.historyText);
        fetchButton.setOnClickListener(v->fetch(false)); videoBtn.setOnClickListener(v->download(false)); audioBtn.setOnClickListener(v->download(true)); settingsBtn.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
    }
    String api(){return prefs.getString("api","https://YOUR-COBALT-INSTANCE.example/");}
    void fetch(boolean audio){ String src=urlInput.getText().toString().trim(); if(!src.contains("instagram.com")){toast("Paste a valid Instagram URL");return;} if(api().contains("YOUR-COBALT")){toast("Open Settings and set your Cobalt API URL");return;} fetchButton.setEnabled(false); resultTitle.setText("Fetching…"); resultCard.setVisibility(View.VISIBLE);
        ApiClient.process(api(),src,"auto",selectedQuality(),"mp3",prefs.getString("key",""),new ApiClient.Callback(){ public void success(String u,String f){runOnUiThread(()->{fetchButton.setEnabled(true);resolvedUrl=u;resolvedFilename=f;resultTitle.setText("Ready to download"); preview.setVideoURI(Uri.parse(u)); preview.setMediaController(new MediaController(MainActivity.this)); preview.requestFocus();});} public void error(String m){runOnUiThread(()->{fetchButton.setEnabled(true);resultTitle.setText("Could not fetch");toast(m);});}});
    }
    String selectedQuality(){String q=quality.getSelectedItem().toString();return q.replace("p","");}
    void download(boolean audio){ if(resolvedUrl.isEmpty()){fetch(false);toast("Fetch the Reel first");return;} String name=resolvedFilename; if(audio) name=name.replaceAll("\\.[^.]+$","")+".mp3"; DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE); DownloadManager.Request r=new DownloadManager.Request(Uri.parse(resolvedUrl)); r.setTitle(name); r.setDescription(audio?"Downloading audio":"Downloading Reel"); r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); r.setAllowedOverMetered(true); r.setAllowedOverRoaming(true); r.setMimeType(audio?"audio/mpeg":"video/mp4"); r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,name); long id=dm.enqueue(r); addHistory(name); toast("Download started"); watchDownload(id,audio);
    }
    void watchDownload(long id, boolean audio){ final DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE); new Thread(()->{while(true){Cursor c=dm.query(new DownloadManager.Query().setFilterById(id)); if(c!=null&&c.moveToFirst()){int st=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)); if(st==DownloadManager.STATUS_SUCCESSFUL){Uri u=dm.getUriForDownloadedFile(id); runOnUiThread(()->sharePrompt(u,audio));c.close();return;} if(st==DownloadManager.STATUS_FAILED){c.close();runOnUiThread(()->toast("Download failed"));return;} c.close();} try{Thread.sleep(700);}catch(Exception ignored){}}}).start();}
    void sharePrompt(Uri uri, boolean audio){new AlertDialog.Builder(this).setTitle("Download complete").setMessage("File saved to Downloads.").setPositiveButton("Share to WhatsApp",(d,w)->share(uri,audio)).setNegativeButton("Close",null).show();}
    void share(Uri uri, boolean audio){Intent i=new Intent(Intent.ACTION_SEND);i.setType(audio?"audio/mpeg":"video/mp4");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{i.setPackage("com.whatsapp");startActivity(i);}catch(Exception e){i.setPackage(null);startActivity(Intent.createChooser(i,"Share"));}}
    void addHistory(String n){String old=prefs.getString("history","");String now=n+(old.isEmpty()?"":"\\n"+old);prefs.edit().putString("history",now).apply();showHistory();}
    void showHistory(){if(historyText==null)return;String h=prefs.getString("history","");historyText.setText(h.isEmpty()?"No downloads yet":h);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
