package com.pravin0raj.reeldownloader;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class ApiClient {
    public interface Callback { void success(String url, String filename); void error(String message); }
    public static void process(String apiBase, String source, String mode, String quality, String audioFormat, String apiKey, Callback cb) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                String base = apiBase.endsWith("/") ? apiBase : apiBase + "/";
                URL u = new URL(base);
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
                c.setDoOutput(true); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("Content-Type", "application/json");
                if (!apiKey.isEmpty()) c.setRequestProperty("Authorization", "Api-Key " + apiKey);
                JSONObject body = new JSONObject(); body.put("url", source); body.put("downloadMode", mode); body.put("videoQuality", quality); body.put("audioFormat", audioFormat); body.put("filenameStyle", "basic");
                try (OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = c.getResponseCode();
                InputStream stream = code >= 400 ? c.getErrorStream() : c.getInputStream();
                StringBuilder s = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) s.append(line); }
                JSONObject json = new JSONObject(s.toString());
                if ("tunnel".equals(json.optString("status")) || "redirect".equals(json.optString("status"))) {
                    cb.success(json.optString("url"), json.optString("filename", "reel_download"));
                } else if ("picker".equals(json.optString("status"))) {
                    if (json.optJSONArray("picker") != null && json.optJSONArray("picker").length() > 0) {
                        JSONObject item = json.optJSONArray("picker").getJSONObject(0); cb.success(item.optString("url"), "reel_download.mp4");
                    } else cb.error("No media found.");
                } else {
                    JSONObject e = json.optJSONObject("error"); cb.error(e != null ? e.optString("code", "API error") : "API error (HTTP " + code + ")");
                }
            } catch (Exception e) { cb.error(e.getMessage() == null ? "Network error" : e.getMessage()); }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }
}
